"""Выгрузка всех сделок из Битрикс24 в формат ЛКМ CRM (JSON для action=import)."""
import json, sys, urllib.request, urllib.parse, re
import os
H = os.environ["BITRIX_HOOK"]  # адрес входящего вебхука, со слешем на конце
def call(m, params):
    data = urllib.parse.urlencode(params, doseq=True).encode()
    return json.load(urllib.request.urlopen(H + m + ".json", data, timeout=60))
def all_items(m, params):
    out, start = [], 0
    while True:
        r = call(m, {**params, "start": start})
        out += r["result"]
        if "next" not in r: return out
        start = r["next"]
fields = call("crm.deal.fields", {})["result"]
enum = {k: {i["ID"]: i["VALUE"] for i in v.get("items", [])} for k, v in fields.items() if v.get("items")}
srcs = {s["STATUS_ID"]: s["NAME"] for s in call("crm.status.list", {"filter[ENTITY_ID]": "SOURCE"})["result"]}
users = {u["ID"]: (u["NAME"] or "").strip() for u in call("user.get", {})["result"]}
users["14"] = "Юрий"
deals = all_items("crm.deal.list", {"select[]": ["*", "UF_*"], "order[ID]": "ASC"})
cids = sorted({d["CONTACT_ID"] for d in deals if d.get("CONTACT_ID")})
contacts = {}
for i in range(0, len(cids), 50):
    for c in all_items("crm.contact.list", {"filter[ID]": cids[i:i+50], "select[]": ["ID", "NAME", "LAST_NAME", "PHONE", "EMAIL"]}):
        contacts[c["ID"]] = c
def ev(k, v):
    if v in (None, "", False, []): return None
    if isinstance(v, list): v = v[0] if v else None
    return enum.get(k, {}).get(str(v), v)
def date(v): return v[:10] if v else None
M = {"UF_CRM_1789052309":"model","UF_CRM_1789052318":"package","UF_CRM_1789052319":"plot","UF_CRM_1789052331":"plot_address",
     "UF_CRM_1789052364":"payment","UF_CRM_1789052383":"term","UF_CRM_1789052392":"decider","UF_CRM_1789052402":"lose_reason",
     "UF_CRM_AVITO_CHAT":"avito_chat","UF_CRM_AVITO_AD":"avito_ad"}
res = []
for d in deals:
    c = contacts.get(d.get("CONTACT_ID") or "", {})
    name = " ".join(x for x in [c.get("NAME"), c.get("LAST_NAME")] if x) or None
    o = {"bitrix_id": int(d["ID"]), "stage": d["STAGE_ID"], "created_at": (d.get("DATE_CREATE") or "")[:19] or None,
         "title": d.get("TITLE") or name or f"Сделка {d['ID']}",
         "phone": (c.get("PHONE") or [{}])[0].get("VALUE"), "email": (c.get("EMAIL") or [{}])[0].get("VALUE"),
         "source": {"UC_AVITO":"Авито","EMAIL":"Авито"}.get(d.get("SOURCE_ID") or "") or srcs.get(d.get("SOURCE_ID") or "") or None, "responsible": users.get(str(d.get("ASSIGNED_BY_ID")), None),
         "amount": float(d["OPPORTUNITY"]) if d.get("OPPORTUNITY") and float(d["OPPORTUNITY"]) > 0 else None,
         "visit_date": date(d.get("UF_CRM_1789052365")), "next_date": date(d.get("UF_CRM_1789052401")),
         "was_in_shop": True if d.get("UF_CRM_1789052400") in ("1", 1, True, "Y") else None,
         "comment": re.sub(r"<[^>]+>", "", d.get("COMMENTS") or "").strip() or None}
    b = d.get("UF_CRM_1789052357")
    if b: 
        n = re.sub(r"[^\d.]", "", str(b).split("|")[0])
        o["budget"] = float(n) if n else None
    for k, f in M.items(): o[f] = ev(k, d.get(k))
    if name and name not in o["title"]: o["title"] = f"{name} — {o['title']}"
    if isinstance(o.get("plot_address"), str) and o["plot_address"].strip()=="" : o["plot_address"]=None
    res.append({k: v for k, v in o.items() if v is not None})
json.dump(res, open(sys.argv[1], "w"), ensure_ascii=False, indent=0)
from collections import Counter
print(len(res), "сделок;", Counter(x["stage"] for x in res))
