#!/usr/bin/env python3
"""ЛКМ CRM — клиент для Claude. Ключ и адрес: env LKM_CRM_KEY / LKM_CRM_API или ~/.lkm_crm (две строки: api, key).
Примеры:
  lkm_crm.py list [--stage UC_X040U9]        — все сделки (кратко)
  lkm_crm.py find Даша                       — поиск по имени/телефону/ссылке на чат
  lkm_crm.py get 12                          — карточка + лента
  lkm_crm.py save 12 '{"next_step":"Звонок","next_date":"2026-10-10"}'
  lkm_crm.py new '{"title":"Иван — 8×3","source":"Авито"}' [--stage UC_X040U9]
  lkm_crm.py move 12 PREPAYMENT_INVOICE
  lkm_crm.py note 12 "Созвонились, едет в субботу"
  lkm_crm.py export backup.json  |  lkm_crm.py import deals.json [--only-new]
"""
import json, os, sys, urllib.request
def cfg():
    api, key = os.environ.get("LKM_CRM_API"), os.environ.get("LKM_CRM_KEY")
    p = os.path.expanduser("~/.lkm_crm")
    if (not api or not key) and os.path.exists(p):
        a, k = open(p).read().split()[:2]; api, key = api or a, key or k
    return api or "https://lenkarkasmodul.shop/crm/api.php", key
def call(action, **kw):
    api, key = cfg()
    req = urllib.request.Request(api, json.dumps({"action": action, "token": key, **kw}, ensure_ascii=False).encode(),
                                 {"Content-Type": "text/plain;charset=utf-8", "User-Agent": "lkm-claude"})
    try: r = json.load(urllib.request.urlopen(req, timeout=120))
    except urllib.error.HTTPError as e: r = json.load(e)
    if not r.get("ok"): sys.exit("Ошибка: " + str(r.get("error")))
    return r
def show(x): print(json.dumps(x, ensure_ascii=False, indent=1))
a = sys.argv[1:]
if not a: sys.exit(__doc__)
c = a[0]
opt = lambda n: a[a.index(n) + 1] if n in a else None
if c == "list":
    st = opt("--stage")
    for d in call("list", light=True)["deals"]:
        if st and d["stage"] != st: continue
        print(d["id"], d["stage"], d.get("title"), "|", d.get("responsible") or "", "|", d.get("next_date") or "", d.get("next_step") or "")
elif c == "find": show(call("find", q=" ".join(a[1:]))["deals"])
elif c == "get": show(call("get", id=int(a[1])))
elif c == "save": show(call("save", id=int(a[1]), changes=json.loads(a[2]))["deal"])
elif c == "new": show(call("save", id=None, changes=json.loads(a[1]), stage=opt("--stage"))["deal"])
elif c == "move": show(call("move", id=int(a[1]), stage=a[2])["deal"])
elif c == "note": call("note", id=int(a[1]), text=" ".join(a[2:])); print("ok")
elif c == "export": json.dump(call("export"), open(a[1], "w"), ensure_ascii=False); print("saved", a[1])
elif c == "import":  # --only-new: не трогать уже перенесённые (синхронизация новых лидов из Битрикса)
    deals = json.load(open(a[1]))
    for i in range(0, len(deals), 100): print(call("import", deals=deals[i:i+100], only_new="--only-new" in a))
elif c == "meta": show(call("meta"))
else: sys.exit(__doc__)
